import sys,os,csv
sys.path.insert(0,r'C:\Users\Lenovo\Downloads\ULLAP\ULLAP\py')
import numpy as np
import analyze_board_capture as abc, analyze_board_session2 as s2
path=sys.argv[1]; tries=sys.argv[2]
x,d,e,_=abc.load_capture(path)
k0,_=abc.align_and_check(x,d,e,'shift'); k0=k0 if k0 is not None else 0
f,nb=s2.freeze_check(x,d,e,k0)
nz=np.flatnonzero(np.abs(x[k0:])>8)
rel=round(3.5-(nz[-1]+1)/abc.FS,3)
ok = f is not None and nb==0
flip = None if f is None else round(rel+f/abc.FS,3)
res=dict(reset_index=k0,key0_release_s=rel,freeze_from_sample=f,mismatch=nb,sw1_flip_s_after_playback=flip,
         full_2s_inside = bool(len(x)-k0 > int(2*abc.FS)+ (0 if True else 0) and nz[-1] < len(x)-k0-1))
if f is not None:
    win=int(.25*abc.FS); end=nz[-1]+1
    res['nr_before_flip_db']=round(abc.nr_db(d[k0+f-win:k0+f],e[k0+f-win:k0+f]),2)
    res['nr_last_0.25s_db']=round(abc.nr_db(d[k0:][end-win:end],e[k0:][end-win:end]),2)
res['VERDICT']='GOOD' if ok and 1.0<=rel<=1.5 and flip is not None and 2.0<=flip<=3.5 else 'BAD - retake'
print(res)
log=os.path.join(os.path.dirname(path),'capture_log.csv')
with open(log,'a',newline='') as fh:
    csv.writer(fh).writerow([os.path.basename(path),tries,1.0,rel,'yes' if ok else f'NO(mismatch {nb})','yes',None,res.get('nr_last_0.25s_db'),res['VERDICT']+f' | sw1 flip at {flip}s'])
