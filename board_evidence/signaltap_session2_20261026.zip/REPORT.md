﻿# ULLAP board session 2 - REPORT

Date: 2026-10-26. DE2-115 (EP4CE115F29C7), Quartus Prime Lite 25.1std. No RTL changes. Nothing committed or pushed in this session.
Setup (confirmed by the person): laptop out -> LINE IN, SW[0]=0, SW[1]=0, same Windows volume as session 1.
Stimulus: stimulus_2s_seed1.zip (unzipped to board_evidence/stimulus_2s/; stereo 48 kHz, 3.5 s = 1 s silence + 0.5 s beep + 2 s scenario), played once, no looping.

## Part A - 12 two-second captures: 12/12 GOOD
Every kept capture is bit-exact from the reset (every e[n] equals the integer model) and has the whole 2 s scenario inside the capture (checked with the repo's analyze_board_capture/session2 functions, see check_capture_2s.py). Build order: NLMS, LMS, NLMS-Shift.
Tries and playback-to-KEY0-release time (kept capture; the release time is derived from the data as 3.5 s minus the end of the signal in the capture; the cue was shown at 1.0 s, KEY0 had to be released before 1.5 s):

| capture | tries | KEY0 release (s after playback start) | NR final 25% (dB) | verdict |
|---|---|---|---|---|
| cap2s_nlms_stationary.csv | 1 | 1.491 | 15.65 | GOOD |
| cap2s_nlms_amp_steps.csv | 4 | 1.34 | 16.76 | GOOD |
| cap2s_nlms_path_switch.csv | 2 | 1.352 | 14.03 | GOOD |
| cap2s_nlms_wav.csv | 1 | 1.316 | 5.8 | GOOD |
| cap2s_lms_stationary.csv | 1 | 1.267 | 15.88 | GOOD |
| cap2s_lms_amp_steps.csv | 1 | 1.283 | 17.13 | GOOD |
| cap2s_lms_path_switch.csv | 2 | 1.301 | 14.67 | GOOD |
| cap2s_lms_wav.csv | 1 | 1.295 | 5.99 | GOOD |
| cap2s_shift_stationary.csv | 1 | 1.245 | 15.8 | GOOD |
| cap2s_shift_amp_steps.csv | 1 | 1.264 | 16.57 | GOOD |
| cap2s_shift_path_switch.csv | 1 | 1.202 | 14.4 | GOOD |
| cap2s_shift_wav.csv | 1 | 1.243 | 5.46 | GOOD |
| cap2s_shift_freeze.csv | 1 | 1.259 | 15.18 | GOOD | sw1 flip at 2.943s |

Retakes: NLMS amp_steps needed 3 failed tries and NLMS path_switch 1, LMS path_switch 1. All of them were bit-exact but the KEY0 release came after 1.5 s, so the start of the scenario was missing from the capture (e.g. release at 1.63 s). The release times logged for those failed tries in capture_log.csv are wrong (they were computed from a failed correlation); only the later estimate is reliable. After the first failures the cue window was changed to a 3-2-1 count-in ending on the green "TAP KEY0 NOW" at 1.0 s; the retakes then passed on the next try.

## Part B - freeze test (NLMS-Shift, stationary): GOOD, 1 try
cap2s_shift_freeze.csv. KEY0 released at 1.259 s after playback start. SW[1] cue "FLIP SW[1] UP NOW" shown at 2.5 s; the data show freeze switching on at post-reset sample 13703 (1.68 s after reset), i.e. SW[1] flipped about 2.94 s after playback start (about 0.44 s after the cue). The board output is bit-exact with the integer model with freeze from that sample (0 mismatches). NR 15.4 dB in the 0.25 s before the switch; -2.8 dB in the last 0.25 s of signal (adaptation stopped, the noise path no longer matches the stored weights while the primary input keeps going).
SW[1] was flipped back down afterwards.

## Part C - LEDs and 10-minute soak (NLMS-Shift)
- Boot (after programming + one KEY0 press): LEDR[6] on; LEDR[0..5] and LEDR[7..9] off, as expected. LEDR[10..17] glow dimly: the design has only LEDR[9:0], so the unused pins are weak pull-ups. Harmless. Observed by the person; photo photos/led_boot.jpeg (one bright red LED, no other flag LED lit; I checked the picture, though the LED numbers cannot be read reliably from it).
- Soak: stationary_noise_48k.wav (6 s) looped with PlayLooping from 15:22:01 for 10 minutes, nobody touched the board (KEY0 pressed once just before). timing_soak.csv recorded at 15:32:01 (600 s): in_valid period 6144 cycles (8138.02 Hz), in_valid to out_valid 38 cycles, busy high 72 cycles = identical to the session-1 timing. LEDs at the end: same as boot, no saturation, error or overrun LED lit (person's observation; photo photos/led_soak.jpeg, again one bright red LED and nothing else lit).

## Part D - DAC word check: done, first try
Added Signal Tap instance dac by hand (no GUI): see anc_t9_with_dac.stp, qsf_dac_section.txt and gen_dac_instance.py. clock CLOCK_50, depth 4096, Transitional storage qualifier on out_valid, no trigger-in, all-don't-care trigger, data = out_valid, d_reg[11..0], e_out[11..0], dac_left_data[15..0] (taps fine), bypass_latched = 42 bits. The CRC in the stp/qsf is a placeholder written identically in both (the GUI-computed value is not known to the command-line flow); Quartus compiled it and Signal Tap ran it without complaint.
- dac_anc.csv (SW[0]=0): the DAC word equals {e, 0000} for all 1792 checked samples, 0 mismatches.
- dac_bypass.csv (SW[0]=1): the top 12 bits of the DAC word equal d for all 1792 samples, 0 mismatches.
SW[0] was put back to 0 afterwards. The repo's analyze_board_session2.py PASS lines are in analysis/board_session2_summary.md.

## Compile summary (0 errors in all)
| build | warnings | worst setup slack (ns) | notes |
|---|---|---|---|
| NLMS (ALGO 1 / EPS 0 / MU 256 / K 3) | 24 | 3.775 | |
| LMS (0 / 2 / 256 / 3) | 25 | 5.681 | |
| NLMS-Shift (2 / 2 / 512 / 3) | 28 | 2.649 | |
| NLMS-Shift + dac instance | 28 | 2.927 | total block memory 2,695,168 / 3,981,312 bits (68%) with all three Signal Tap instances |
The total block memory figure was only recorded for the dac build (the fit summary was overwritten by later compiles).

## Results (repo analyzer, analysis/)
Every board capture is bit-exact. Measured board NR is lower than the integer model on the 8 kHz stimulus (-3 to -10 dB depending on scenario, e.g. NLMS-Shift stationary 15.8 vs 22.7 dB), see the table below: the model runs on the ideal 8 kHz signal while the board gets the 48 kHz stimulus through the analog codec path. This is a finding, not a failure of the bit-exact check.

# Board session 2

| Algorithm | Scenario | T9 | NR board (dB) | NR model, same signal (dB) | Difference |
|---|---|---|---|---|---|
| LMS | amp_steps | bit-exact | 17.13 | 27.71 | -10.58 |
| LMS | path_switch | bit-exact | 14.67 | 19.84 | -5.18 |
| LMS | stationary | bit-exact | 15.88 | 22.77 | -6.89 |
| LMS | wav | bit-exact | 5.99 | 9.11 | -3.12 |
| NLMS | amp_steps | bit-exact | 16.76 | 27.19 | -10.42 |
| NLMS | path_switch | bit-exact | 14.03 | 19.06 | -5.03 |
| NLMS | stationary | bit-exact | 15.65 | 21.6 | -5.95 |
| NLMS | wav | bit-exact | 5.8 | 8.72 | -2.92 |
| NLMS-Shift | amp_steps | bit-exact | 16.57 | 25.79 | -9.22 |
| NLMS-Shift | path_switch | bit-exact | 14.4 | 19.86 | -5.46 |
| NLMS-Shift | stationary | bit-exact | 15.8 | 22.68 | -6.87 |
| NLMS-Shift | wav | bit-exact | 5.46 | 8.63 | -3.18 |

- Freeze (NLMS-Shift, stationary): bit-exact with freeze on from sample 13703 (1.68 s after reset); NR 15.4 dB in the 0.25 s before the switch, -2.8 dB in the last 0.25 s of signal
- DAC word, ANC (SW[0] = 0): = {e, 0000}: PASS, 1792 samples match, 0 differ
- DAC word, bypass (SW[0] = 1): top 12 bits = d: PASS, 1792 samples match, 0 differ
- GPIO timing at the end of the 10-minute soak: in_valid period (cycles) 6144, sample rate (Hz) 8138.02, in_valid to out_valid (cycles) 38, busy high (cycles) 72


## Not done / notes
- Photos: led_boot.jpeg and led_soak.jpeg are included under photos/. setup.jpg (bench photo with a Signal Tap waveform on the laptop) was not taken; no Quartus GUI was open.
- quartus/anc_de2_115.qsf is restored to the NLMS-Shift values and quartus/anc_t9.stp is restored to the pre-Part-D version. Both differ from the committed bench commit only in the state the Quartus tools left them in before Part D (the stp was re-saved by Signal Tap; it shows as modified in git). The dac versions are included here, not in quartus/.
- The board is NOT in the stock state: it currently runs the NLMS-Shift + dac bitstream (programmed for Part D). SW[0] and SW[1] are down.
- Nothing was committed or pushed.

