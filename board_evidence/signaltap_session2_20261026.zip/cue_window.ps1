param([string]$Scn,[string]$Label,[double]$CueAt=1.0,[string]$Dir='stimulus_2s',[int]$Loop=0,[double]$FlipAt=0)
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
$f=New-Object Windows.Forms.Form; $f.TopMost=$true; $f.Width=700; $f.Height=320; $f.StartPosition='CenterScreen'; $f.Text="ULLAP capture: $Label"
$l=New-Object Windows.Forms.Label; $l.Dock='Fill'; $l.TextAlign='MiddleCenter'; $l.Font=New-Object Drawing.Font('Segoe UI',28,[Drawing.FontStyle]::Bold)
$l.Text="Click START, then press KEY0`nwhen the window turns green"; $f.Controls.Add($l)
$b=New-Object Windows.Forms.Button; $b.Dock='Bottom'; $b.Height=70; $b.Text='START'; $b.Font=New-Object Drawing.Font('Segoe UI',20); $f.Controls.Add($b)
$sw=New-Object Diagnostics.Stopwatch
$t=New-Object Windows.Forms.Timer; $t.Interval=20
$pl=New-Object Media.SoundPlayer "C:\Users\Lenovo\Downloads\ULLAP\ULLAP\board_evidence\$Dir\${Scn}_noise_48k.wav"
$pl.Load()
$b.Add_Click({ $b.Enabled=$false; $b.Text='running'; $pl.Play(); $sw.Start(); $t.Start() })
$t.Add_Tick({ $s=$sw.Elapsed.TotalSeconds
 if($s -lt ($CueAt-0.67)){ $l.Text="3"; $l.BackColor='Gold' } elseif($s -lt ($CueAt-0.33)){ $l.Text="2"; $l.BackColor='Gold' } elseif($s -lt $CueAt){ $l.Text="1"; $l.BackColor='Gold' }
 elseif($s -lt ($CueAt+0.5)){ $l.Text="TAP KEY0 NOW (quick tap!)"; $l.BackColor='LimeGreen' }
 elseif($FlipAt -gt 0 -and $s -ge $FlipAt -and $s -lt ($FlipAt+1.0)){ $l.Text="FLIP SW[1] UP NOW"; $l.BackColor='Orange' }
 elseif($s -lt 5.5){ $l.Text="wait ($([int](5.5-$s)))"; $l.BackColor='LightSkyBlue' }
 else { $t.Stop(); $f.Close() } })
[void]$f.ShowDialog()


