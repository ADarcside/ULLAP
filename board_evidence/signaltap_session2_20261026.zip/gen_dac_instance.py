import re,sys
S=sys.argv[1]   # scratchpad
Q=r'C:\Users\Lenovo\Downloads\ULLAP\ULLAP\quartus'
DATA_NAMES=sys.argv[2:] # extra nodes for the 16-bit bus: either dac_left_data or anc_out_latched+adc_right_raw
CRC='5A5A5A5'   # 28-bit placeholder (hex), written into both stp and qsf
stp=open(S+r'\anc_t9.stp.orig',encoding='utf-8').read()
qsf=open(S+r'\anc_de2_115.qsf.orig',encoding='utf-8').read()
names=[]
for n in range(12): names.append(f'anc_core:u_anc_core|e_out[{n}]')
names.append('anc_core:u_anc_core|out_valid'); names.append('bypass_latched')
for n in range(12): names.append(f'd_reg[{n}]')
buses16=[]
for b in DATA_NAMES:
    for n in range(16): names.append(f'{b}[{n}]')
names=sorted(names)
idx={n:i for i,n in enumerate(names)}
N=len(names)
def node(tag,name,i,sq=False):
    return (f'<{tag} data_index="{i}" duplicate_name_allowed="false" is_data_input="true" is_node_valid="true" is_selected="false" '
            f'is_storage_input="{"true" if sq else "false"}" is_trigger_input="true" level-0="dont_care" name="{name}" pwr_level-0="dont_care" '
            'pwr_storage-0="dont_care" pwr_storage-1="dont_care" pwr_storage-2="dont_care" storage-0="dont_care" storage-1="dont_care" '
            f'storage-2="dont_care" storage_index="{0 if sq else i}" tap_mode="classic" trigger_index="{i}" type="unknown"/>')
def view(tag):
    out=[]
    out.append(node(tag,'anc_core:u_anc_core|out_valid',idx['anc_core:u_anc_core|out_valid'],True))
    out.append(node(tag,'bypass_latched',idx['bypass_latched']))
    bus='node' if tag=='node' else 'bus'
    groups=[('d_reg',12,'d_reg[11..0]'),('anc_core:u_anc_core|e_out',12,'anc_core:u_anc_core|e_out[11..0]')]+[(b,16,f'{b}[15..0]') for b in DATA_NAMES]
    for base,w,label in groups:
        out.append(f'<{bus} is_selected="false" level-0="alt_or" name="{label}" order="msb_to_lsb" storage-0="alt_or" storage-1="alt_or" storage-2="alt_or" type="register">')
        for n in range(w-1,-1,-1):
            nm=f'{base}[{n}]'; out.append(node(tag,nm,idx[nm]))
        out.append(f'</{bus}>')
    return '\n'.join(out)
wires=lambda: '\n'.join(f'<wire name="{n}" tap_mode="classic"/>' for n in names)
# trigger block: copy of cap's trigger element structure (storage qualifier events), CRC and trigger_in changed
m=re.search(r'(<trigger CRC="[^"]*".*?</storage_qualifier_events>)',stp,re.S)
trig=m.group(1)
trig=re.sub(r'CRC="[^"]*"',f'CRC="{CRC}"',trig,1)
trig=re.sub(r'name="trigger:[^"]*"','name="trigger: 2026/10/26 16:00:00  #5"',trig,1)
trig=re.sub(r'storage_qualifier_port_is_pin="[^"]*"','storage_qualifier_port_is_pin="false"',trig,1)
trig=re.sub(r'trigger_in="rising edge"','trigger_in="dont_care"',trig,1)
trig=trig.replace('gap_record="false"','gap_record="false"',1)
inst=f'''<instance enabled="true" entity_name="sld_signaltap" is_auto_node="yes" is_expanded="true" name="dac" source_file="sld_signaltap.vhd">
<node_ip_info instance_id="2" mfg_id="110" node_id="0" version="6"/>
<signal_set global_temp="1" is_expanded="true" name="signal_set: 2026/10/26 16:00:00  #4">
<clock name="CLOCK_50" polarity="posedge" tap_mode="probeonly"/>
<config is_hps_trigger_out_selected="false" pipeline_level="5" ram_type="AUTO" reserved_data_nodes="0" reserved_storage_qualifier_nodes="0" reserved_trigger_nodes="0" sample_depth="4096" trigger_in_enable="no" trigger_out_enable="no"/>
<top_entity/>
<signal_vec>
<trigger_input_vec>
{wires()}
</trigger_input_vec>
<data_input_vec>
{wires()}
</data_input_vec>
<storage_qualifier_input_vec>
<wire name="anc_core:u_anc_core|out_valid" tap_mode="classic"/>
</storage_qualifier_input_vec>
</signal_vec>
<presentation>
<unified_setup_data_view>
{view('node')}
</unified_setup_data_view>
<data_view>
{view('net')}
</data_view>
<setup_view>
{view('net')}
</setup_view>
<trigger_out_editor/>
</presentation>
{trig}
</trigger>
</signal_set>
<position_info>
<single attribute="active tab" value="1"/>
</position_info>
</instance>
'''
# the 'trig' ends at </storage_qualifier_events>; close the trigger element after it (inst template already does)
stp2=stp.replace('<mnemonics/>',inst+'<mnemonics/>',1)
stp2=stp2.replace('</display_tree>','<display_branch instance="dac" log="USE_GLOBAL_TEMP" signal_set="USE_GLOBAL_TEMP" trigger="USE_GLOBAL_TEMP"/>\n</display_tree>',1)
open(Q+r'\anc_t9.stp','w',encoding='utf-8').write(stp2)
# ---- qsf section
L=[]
g=lambda k,v='' : f'set_global_assignment -name {k} {v} -section_id dac'
i_=lambda k,to : f'set_instance_assignment -name {k} -to {to} -section_id dac'
L+= [g('SLD_NODE_CREATOR_ID','110'),g('SLD_NODE_ENTITY_NAME','sld_signaltap'),i_('POST_FIT_CONNECT_TO_SLD_NODE_ENTITY_PORT acq_clk','CLOCK_50')]
q=lambda s: f'"{s}"' if re.search(r'[:|]',s) else s
for n in names:
    L.append(i_(f'CONNECT_TO_SLD_NODE_ENTITY_PORT acq_trigger_in[{idx[n]}]',q(n)))
for n in names:
    L.append(i_(f'CONNECT_TO_SLD_NODE_ENTITY_PORT acq_data_in[{idx[n]}]',q(n)))
L.append(i_('CONNECT_TO_SLD_NODE_ENTITY_PORT acq_storage_qualifier_in[0]','"anc_core:u_anc_core|out_valid"'))
crc=int(CRC,16)
for b in range(32):
    L.append(i_(f'POST_FIT_CONNECT_TO_SLD_NODE_ENTITY_PORT crc[{b}]','dac|'+('vcc' if (crc>>b)&1 else 'gnd')))
P=lambda s: g('SLD_NODE_PARAMETER_ASSIGNMENT',f'"{s}"')
maskn=3*N+32
for s in ['SLD_RAM_BLOCK_TYPE=AUTO',f'SLD_DATA_BITS={N}',f'SLD_TRIGGER_BITS={N}','SLD_NODE_INFO=805334530','SLD_POWER_UP_TRIGGER=0','SLD_SEGMENT_SIZE=4096',
          'SLD_ATTRIBUTE_MEM_MODE=OFF','SLD_STATE_FLOW_USE_GENERATED=0','SLD_STATE_BITS=11','SLD_BUFFER_FULL_STOP=1','SLD_CURRENT_RESOURCE_WIDTH=1',
          'SLD_INCREMENTAL_ROUTING=1','SLD_TRIGGER_LEVEL=1','SLD_SAMPLE_DEPTH=4096','SLD_TRIGGER_IN_ENABLED=0','SLD_TRIGGER_PIPELINE=0','SLD_RAM_PIPELINE=5',
          'SLD_COUNTER_PIPELINE=0','SLD_ADVANCED_TRIGGER_ENTITY=basic,1,','SLD_TRIGGER_LEVEL_PIPELINE=1','SLD_ENABLE_ADVANCED_TRIGGER=0','SLD_STORAGE_QUALIFIER_BITS=1',
          'SLD_INVERSION_MASK='+'0'*maskn,f'SLD_INVERSION_MASK_LENGTH={maskn}','SLD_STORAGE_QUALIFIER_INVERSION_MASK_LENGTH=2','SLD_STORAGE_QUALIFIER_GAP_RECORD=0','SLD_STORAGE_QUALIFIER_MODE=TRANSITIONAL']:
    L.append(P(s))
open(Q+r'\anc_de2_115.qsf','w',encoding='ascii').write(qsf.rstrip('\n')+'\n'+'\n'.join(L)+'\n')
print('instance bits',N,'mask',maskn,'qsf lines',len(L))
