import sys,os,re,csv
sys.path.insert(0,r'C:\Users\Lenovo\Downloads\ULLAP\ULLAP\py')
import numpy as np
import analyze_board_capture as abc
import analyze_board_session2 as s2
path=sys.argv[1]; tries=sys.argv[2] if len(sys.argv)>2 else '1'
m=re.match(r'cap2s_(lms|nlms|shift)_(.+)\.csv$',os.path.basename(path)); algo,scen=m.groups()
x,d,e,_=abc.load_capture(path)
n=int(round(s2.SECONDS*abc.FS))
k,bad=abc.align_and_check(x,d,e,algo)
res={'file':os.path.basename(path),'samples':len(x),'distinct_x':len(set(x.tolist())),'distinct_e':len(set(e.tolist()))}
good=k is not None and bad==0
res['bit_exact']= 'yes' if good else f'NO (k={k}, bad={bad})'
if k is not None:
    s,rho=s2.scenario_start(x[k:],scen)
    res['reset_index']=k
    res['post_reset_samples']=len(x)-k
    res['scenario_start_s']=None if s is None else round(s/abc.FS,3)
    res['corr']=round(rho,3)
    inside = s is not None and s+n<=len(x)-k and rho>=0.5
    res['full_2s_inside']='yes' if inside else 'NO'
    # KEY0 release relative to playback start: scenario begins at 1.5 s of the file
    nz=np.flatnonzero(np.abs(x[k:])>8); res['key0_release_s_after_playback']= round(3.5-(nz[-1]+1)/abc.FS,3)
    if res['key0_release_s_after_playback']>1.5: res['late_by_s']=round(res['key0_release_s_after_playback']-1.5,3)
    good = good and inside
    if inside:
        lo=s+int(.75*n); res['nr_final_db']=round(abc.nr_db(d[k:][lo:s+n],e[k:][lo:s+n]),2)
res['VERDICT']='GOOD' if good else 'BAD - retake'
print(res)
log=os.path.join(os.path.dirname(path),'capture_log.csv')
new=not os.path.exists(log)
with open(log,'a',newline='') as f:
    w=csv.writer(f)
    if new: w.writerow(['file','try','cue_s_after_playback','key0_release_s_after_playback_(from data)','bit_exact','full_2s_inside','scenario_start_s','nr_final_db','verdict'])
    w.writerow([res['file'],tries,1.0,res.get('key0_release_s_after_playback'),res['bit_exact'],res.get('full_2s_inside'),res.get('scenario_start_s'),res.get('nr_final_db'),res['VERDICT']])


