import sys,csv
def load(p):
    L=open(p).read().splitlines()
    i=[k for k,l in enumerate(L) if l.startswith('time unit')][0]
    h=[c.strip() for c in L[i].split(',')]
    ix={n:h.index(n) for n in h if n.endswith('[11..0]') or n.endswith('out_valid') or n=='rst_sync_2'}
    rows=[]
    for l in L[i+1:]:
        c=[x.strip() for x in l.split(',')]
        if len(c)<len(h): continue
        rows.append(c)
    g=lambda k:[r[[v for n,v in ix.items() if k in n][0]] for r in rows]
    return g('out_valid'),g('x_reg'),g('d_reg'),g('e_out'),g('rst_sync_2')
def s(v):
    x=int(v,16); return x-4096 if x>=2048 else x
ov,x,d,e,r=load(sys.argv[1])
n=len(ov); print('rows',n,'out_valid=1:',sum(o=='1' for o in ov))
sel=[k for k in range(n) if ov[k]=='1' and 'X' not in x[k]]
print('samples',len(sel))
for nm,a in (('x',x),('d',d),('e',e)):
    v=[s(a[k]) for k in sel]; print(nm,'distinct',len(set(v)),'min',min(v),'max',max(v),'rms',round((sum(t*t for t in v)/len(v))**.5,1))
rs=[r[k] for k in range(n)]; print('rst_sync_2 changes',sum(1 for k in range(1,n) if rs[k]!=rs[k-1]))

